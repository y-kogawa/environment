var Hoge = require('./module/Hoge');

var hoge = new Hoge('hage');
hoge.callName();
